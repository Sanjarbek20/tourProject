import { tours, bookings, contacts, workers } from "@shared/schema";
import type { Tour, InsertTour, Booking, InsertBooking, Contact, InsertContact, Worker, InsertWorker } from "@shared/schema";
import { BookingModel } from './mongodb';

export interface IStorage {
  // Tours
  getTours(): Promise<Tour[]>;
  getTour(id: number): Promise<Tour | undefined>;
  getToursByCategory(category: string): Promise<Tour[]>;

  // Bookings
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBooking(id: number): Promise<Booking | undefined>;
  getAllBookings(): Promise<Booking[]>;

  // Contacts
  createContact(contact: InsertContact): Promise<Contact>;

  // Workers
  createWorker(worker: InsertWorker): Promise<Worker>;
  getWorkerByUsername(username: string): Promise<Worker | undefined>;
}

export class MemStorage implements IStorage {
  private tours: Map<number, Tour>;
  private contacts: Map<number, Contact>;
  private workers: Map<number, Worker>;
  private currentTourId: number;
  private currentContactId: number;
  private currentWorkerId: number;

  constructor() {
    this.tours = new Map();
    this.contacts = new Map();
    this.workers = new Map();
    this.currentTourId = 1;
    this.currentContactId = 1;
    this.currentWorkerId = 1;

    // Initialize with mock tour data
    const mockTours: InsertTour[] = [
      {
        title: "Historical Samarkand",
        description: "Explore the majestic Registan Square and ancient architecture of Samarkand",
        image: "https://images.unsplash.com/photo-1599324487717-071bb3168db0",
        duration: 3,
        price: 299,
        location: "Samarkand",
        category: "cultural",
        included: ["Hotel", "Guide", "Transportation", "Entry Fees"],
        difficulty: "easy"
      },
      {
        title: "Bukhara Heritage Tour",
        description: "Visit the ancient city of Bukhara with its stunning mosques and madrasas",
        image: "https://images.unsplash.com/photo-1584819764796-0fe40600a559",
        duration: 2,
        price: 249,
        location: "Bukhara",
        category: "cultural",
        included: ["Guide", "Entry Fees", "Lunch", "Transportation"],
        difficulty: "easy"
      },
      {
        title: "Khiva Ancient City",
        description: "Walk through the well-preserved medieval city of Khiva",
        image: "https://images.unsplash.com/photo-1562644592-5d3e9f7676bd",
        duration: 2,
        price: 199,
        location: "Khiva",
        category: "cultural",
        included: ["Guide", "Entry Fees", "Traditional Lunch"],
        difficulty: "easy"
      },
      {
        title: "Tashkent Modern Tour",
        description: "Experience the vibrant capital city with its mix of modern and Soviet architecture",
        image: "https://images.unsplash.com/photo-1549879615-9513db617351",
        duration: 1,
        price: 149,
        location: "Tashkent",
        category: "cultural",
        included: ["Metro Tour", "Chorsu Bazaar Visit", "City Guide"],
        difficulty: "easy"
      },
      {
        title: "Chimgan Mountains Adventure",
        description: "Hiking and outdoor activities in the beautiful Chimgan Mountains",
        image: "https://images.unsplash.com/photo-1604608672516-f1b9b1d37064",
        duration: 2,
        price: 299,
        location: "Chimgan",
        category: "adventure",
        included: ["Equipment", "Guide", "Lunch Pack", "Transport"],
        difficulty: "moderate"
      },
      {
        title: "Aral Sea Expedition",
        description: "Visit the famous Aral Sea and learn about its environmental history",
        image: "https://images.unsplash.com/photo-1566138686723-00038c5fca9e",
        duration: 3,
        price: 449,
        location: "Moynak",
        category: "adventure",
        included: ["4x4 Transport", "Camping Equipment", "Meals", "Guide"],
        difficulty: "challenging"
      },
      {
        title: "Nurata Yurt Stay",
        description: "Experience traditional nomadic life in the Nurata Mountains",
        image: "https://images.unsplash.com/photo-1595100417477-45640c59d67c",
        duration: 2,
        price: 279,
        location: "Nurata",
        category: "cultural",
        included: ["Yurt Accommodation", "Traditional Meals", "Camel Ride"],
        difficulty: "easy"
      },
      {
        title: "Fergana Valley Culture",
        description: "Discover the rich cultural heritage and artisans of the Fergana Valley",
        image: "https://images.unsplash.com/photo-1591805058622-5fa9714a3481",
        duration: 3,
        price: 329,
        location: "Fergana Valley",
        category: "cultural",
        included: ["Silk Factory Visit", "Ceramics Workshop", "Local Home Stay"],
        difficulty: "easy"
      },
      {
        title: "Surkhandarya Nature Tour",
        description: "Explore the natural wonders of Surkhandarya region",
        image: "https://images.unsplash.com/photo-1569406593270-3258a76d3c7d",
        duration: 4,
        price: 399,
        location: "Surkhandarya",
        category: "nature",
        included: ["National Park Entry", "Guided Hikes", "Local Accommodation"],
        difficulty: "moderate"
      },
      {
        title: "Tashkent Food Tour",
        description: "Taste the diverse flavors of Uzbek cuisine in the capital",
        image: "https://images.unsplash.com/photo-1583280323355-fa5e6121a3cd",
        duration: 1,
        price: 89,
        location: "Tashkent",
        category: "food",
        included: ["Food Tastings", "Market Visit", "Cooking Class"],
        difficulty: "easy"
      }
    ];

    mockTours.forEach(tour => {
      const id = this.currentTourId++;
      this.tours.set(id, { ...tour, id });
    });

    // Initialize with a default worker
    this.createWorker({
      username: "admin",
      password: "admin123" // In a real app, this would be hashed
    });
  }

  async getTours(): Promise<Tour[]> {
    return Array.from(this.tours.values());
  }

  async getTour(id: number): Promise<Tour | undefined> {
    return this.tours.get(id);
  }

  async getToursByCategory(category: string): Promise<Tour[]> {
    return Array.from(this.tours.values()).filter(
      tour => tour.category === category
    );
  }

  // MongoDB Booking Operations
  async createBooking(booking: InsertBooking): Promise<Booking> {
    const mongoBooking = new BookingModel(booking);
    const savedBooking = await mongoBooking.save();
    return {
      id: savedBooking._id,
      ...savedBooking.toObject(),
    } as Booking;
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    const booking = await BookingModel.findById(id);
    if (!booking) return undefined;
    return {
      id: booking._id,
      ...booking.toObject(),
    } as Booking;
  }

  async getAllBookings(): Promise<Booking[]> {
    const bookings = await BookingModel.find().sort({ createdAt: -1 });
    return bookings.map(booking => ({
      id: booking._id,
      ...booking.toObject(),
    })) as Booking[];
  }

  async createContact(contact: InsertContact): Promise<Contact> {
    const id = this.currentContactId++;
    const newContact = { ...contact, id, createdAt: new Date() };
    this.contacts.set(id, newContact);
    return newContact;
  }

  async createWorker(worker: InsertWorker): Promise<Worker> {
    const id = this.currentWorkerId++;
    const newWorker = { ...worker, id };
    this.workers.set(id, newWorker);
    return newWorker;
  }

  async getWorkerByUsername(username: string): Promise<Worker | undefined> {
    return Array.from(this.workers.values()).find(
      worker => worker.username === username
    );
  }
}

export const storage = new MemStorage();