import type { Express } from "express";
import { createServer } from "http";
import { storage } from "./storage";
import { insertBookingSchema, insertContactSchema } from "@shared/schema";
import { z } from "zod";
import session from "express-session";
import MemoryStore from "memorystore";

const SessionStore = MemoryStore(session);

export async function registerRoutes(app: Express) {
  // Setup session middleware
  app.use(
    session({
      store: new SessionStore({
        checkPeriod: 86400000, // prune expired entries every 24h
      }),
      secret: "your-secret-key", // In production, use environment variable
      resave: false,
      saveUninitialized: false,
      cookie: { secure: process.env.NODE_ENV === "production" },
    })
  );

  // Authentication middleware
  const requireAuth = (req: any, res: any, next: any) => {
    if (!req.session.workerId) {
      res.status(401).json({ message: "Unauthorized" });
      return;
    }
    next();
  };

  app.get("/api/tours", async (req, res) => {
    const category = req.query.category as string | undefined;
    const tours = category 
      ? await storage.getToursByCategory(category)
      : await storage.getTours();
    res.json(tours);
  });

  app.get("/api/tours/:id", async (req, res) => {
    const id = parseInt(req.params.id);
    const tour = await storage.getTour(id);
    if (!tour) {
      res.status(404).json({ message: "Tour not found" });
      return;
    }
    res.json(tour);
  });

  // Protected route - only accessible to logged-in workers
  app.get("/api/bookings", requireAuth, async (_req, res) => {
    const bookings = await storage.getAllBookings();
    res.json(bookings);
  });

  app.post("/api/bookings", async (req, res) => {
    try {
      const booking = insertBookingSchema.parse(req.body);
      const newBooking = await storage.createBooking(booking);
      res.status(201).json(newBooking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid booking data", errors: error.errors });
        return;
      }
      throw error;
    }
  });

  app.post("/api/contact", async (req, res) => {
    try {
      const contact = insertContactSchema.parse(req.body);
      const newContact = await storage.createContact(contact);
      res.status(201).json(newContact);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid contact data", errors: error.errors });
        return;
      }
      throw error;
    }
  });

  // Worker authentication routes
  app.post("/api/worker/login", async (req, res) => {
    const { username, password } = req.body;
    const worker = await storage.getWorkerByUsername(username);

    if (!worker || worker.password !== password) {
      res.status(401).json({ message: "Invalid credentials" });
      return;
    }

    (req.session as any).workerId = worker.id;
    res.json({ success: true });
  });

  app.post("/api/worker/logout", (req, res) => {
    req.session.destroy(() => {
      res.json({ success: true });
    });
  });

  const httpServer = createServer(app);
  return httpServer;
}