import mongoose from 'mongoose';
import { log } from './vite';

const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/dildoratour';

mongoose.connect(MONGODB_URI)
  .then(() => {
    log('Connected to MongoDB successfully');
  })
  .catch((error) => {
    log(`MongoDB connection error: ${error}`);
    process.exit(1);
  });

// Booking Schema
const bookingSchema = new mongoose.Schema({
  tourId: { type: Number, required: true },
  name: { type: String, required: true },
  email: { type: String, required: true },
  date: { type: Date, required: true },
  participants: { type: Number, required: true },
  specialRequests: { type: String },
  createdAt: { type: Date, default: Date.now }
});

export const BookingModel = mongoose.model('Booking', bookingSchema);
