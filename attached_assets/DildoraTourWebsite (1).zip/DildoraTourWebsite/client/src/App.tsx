import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { Navbar } from "@/components/navbar";
import { Footer } from "@/components/footer";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import Tours from "@/pages/tours";
import Tour from "@/pages/tour";
import About from "@/pages/about";
import Contact from "@/pages/contact";
import WorkerDashboard from "@/pages/worker";
import WorkerLogin from "@/pages/worker-login";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/tours" component={Tours} />
      <Route path="/tours/:id" component={Tour} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/worker/login" component={WorkerLogin} />
      <Route path="/worker" component={WorkerDashboard} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <div className="min-h-screen flex flex-col">
        <Navbar />
        <main className="flex-1 py-8 md:py-12">
          <Router />
        </main>
        <Footer />
      </div>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;