import { useQuery } from "@tanstack/react-query";
import { TourCard } from "@/components/tour-card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Tour } from "@shared/schema";
import { TOUR_CATEGORIES } from "@/lib/constants";
import { useState } from "react";

export default function Tours() {
  const [category, setCategory] = useState<string>("all");

  const { data: tours, isLoading } = useQuery<Tour[]>({
    queryKey: ["/api/tours", category],
    queryFn: async () => {
      const url = new URL("/api/tours", window.location.origin);
      if (category && category !== "all") {
        url.searchParams.set("category", category);
      }
      const res = await fetch(url);
      if (!res.ok) throw new Error("Failed to fetch tours");
      return res.json();
    }
  });

  return (
    <div className="container px-4 md:px-6">
      <h1 className="text-4xl font-bold mb-8">Our Tours</h1>

      <div className="mb-8">
        <Select 
          value={category} 
          onValueChange={setCategory}
        >
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="All Categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {TOUR_CATEGORIES.map(cat => (
              <SelectItem 
                key={cat.value} 
                value={cat.value}
              >
                {cat.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {[1,2,3,4,5,6].map(i => (
            <div key={i} className="h-[400px] animate-pulse bg-muted rounded-lg" />
          ))}
        </div>
      ) : (
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {tours?.map(tour => (
            <TourCard key={tour.id} tour={tour} />
          ))}
        </div>
      )}
    </div>
  );
}