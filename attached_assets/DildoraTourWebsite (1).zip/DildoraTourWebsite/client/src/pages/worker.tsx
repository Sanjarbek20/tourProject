import { useQuery, useMutation } from "@tanstack/react-query";
import type { Booking, Tour } from "@shared/schema";
import { format } from "date-fns";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import { LanguageSwitcher } from "@/components/language-switcher";

export default function WorkerDashboard() {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  const { data: bookings, isLoading: isLoadingBookings, error } = useQuery<Booking[]>({
    queryKey: ["/api/bookings"],
    onError: (error: any) => {
      if (error.message.includes("401")) {
        setLocation("/worker/login");
      }
    }
  });

  const { data: tours } = useQuery<Tour[]>({
    queryKey: ["/api/tours"]
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/worker/logout", {});
    },
    onSuccess: () => {
      toast({
        title: t('worker.dashboard.logout'),
        description: t('worker.login.success'),
      });
      setLocation("/worker/login");
    },
  });

  if (error) {
    return null; // Will redirect to login
  }

  if (isLoadingBookings) {
    return <div className="container py-12 animate-pulse" />;
  }

  return (
    <div className="container py-12">
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-4xl font-bold">{t('worker.dashboard.title')}</h1>
        <div className="flex items-center gap-4">
          <LanguageSwitcher />
          <Button 
            variant="outline"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
          >
            {logoutMutation.isPending 
              ? t('worker.dashboard.loggingOut')
              : t('worker.dashboard.logout')}
          </Button>
        </div>
      </div>

      <div className="grid gap-6">
        {bookings?.map((booking) => {
          const tour = tours?.find(t => t.id === booking.tourId);

          return (
            <Card key={booking.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="text-xl font-semibold">
                      {t('worker.dashboard.bookingDetails.bookingNumber', { number: booking.id })}
                    </h3>
                    <p className="text-muted-foreground">
                      {t('worker.dashboard.bookingDetails.tour', { title: tour?.title || 'Loading...' })}
                    </p>
                  </div>
                  <Badge>
                    {format(new Date(booking.date), 'PPP')}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  <div>
                    <h4 className="font-medium mb-2">{t('worker.dashboard.bookingDetails.customerDetails')}</h4>
                    <p>{t('worker.dashboard.bookingDetails.name', { name: booking.name })}</p>
                    <p>{t('worker.dashboard.bookingDetails.email', { email: booking.email })}</p>
                    <p>{t('worker.dashboard.bookingDetails.participants', { count: booking.participants })}</p>
                  </div>
                  {booking.specialRequests && (
                    <div>
                      <h4 className="font-medium mb-2">{t('worker.dashboard.bookingDetails.specialRequests')}</h4>
                      <p>{booking.specialRequests}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          );
        })}

        {(!bookings || bookings.length === 0) && (
          <div className="text-center py-12 text-muted-foreground">
            {t('worker.dashboard.noBookings')}
          </div>
        )}
      </div>
    </div>
  );
}