export default function About() {
  return (
    <div className="container py-12">
      <h1 className="text-4xl font-bold mb-8">About DildoraTour</h1>
      
      <div className="prose max-w-none">
        <p className="lead">
          DildoraTour is your gateway to experiencing the rich cultural heritage and natural beauty of Uzbekistan. With years of expertise in crafting unique travel experiences, we pride ourselves on providing authentic and memorable tours that showcase the best of our country.
        </p>

        <h2>Our Mission</h2>
        <p>
          To provide exceptional travel experiences that connect visitors with the heart and soul of Uzbekistan, while promoting sustainable tourism and supporting local communities.
        </p>

        <h2>Why Choose Us</h2>
        <ul>
          <li>Expert local guides with deep knowledge of Uzbekistan's history and culture</li>
          <li>Carefully curated itineraries that blend popular attractions with hidden gems</li>
          <li>Small group sizes for personalized attention</li>
          <li>Support for local communities and sustainable tourism practices</li>
          <li>24/7 customer support throughout your journey</li>
        </ul>

        <h2>Our Team</h2>
        <p>
          Our team consists of passionate travel experts, experienced guides, and dedicated support staff who work together to ensure your journey through Uzbekistan is unforgettable.
        </p>
      </div>
    </div>
  );
}
