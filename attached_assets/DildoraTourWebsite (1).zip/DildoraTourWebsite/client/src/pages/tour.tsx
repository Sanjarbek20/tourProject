import { useQuery, useMutation } from "@tanstack/react-query";
import { useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin, Check } from "lucide-react";
import type { Tour } from "@shared/schema";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertBookingSchema } from "@shared/schema";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

export default function TourPage() {
  const { id } = useParams();
  const { toast } = useToast();

  const { data: tour, isLoading } = useQuery<Tour>({
    queryKey: [`/api/tours/${id}`]
  });

  const form = useForm({
    resolver: zodResolver(insertBookingSchema),
    defaultValues: {
      tourId: id ? parseInt(id) : 0,
      name: "",
      email: "",
      date: new Date(),
      participants: 1,
      specialRequests: ""
    }
  });

  const bookingMutation = useMutation({
    mutationFn: async (data: any) => {
      await apiRequest("POST", "/api/bookings", data);
    },
    onSuccess: () => {
      toast({
        title: "Booking submitted",
        description: "We'll contact you soon to confirm your booking."
      });
      form.reset();
    }
  });

  if (isLoading) {
    return <div className="container py-12 animate-pulse" />;
  }

  if (!tour) {
    return <div className="container py-12">Tour not found</div>;
  }

  return (
    <div className="container py-12">
      <div className="grid gap-12 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="aspect-video mb-8">
            <img
              src={tour.image}
              alt={tour.title}
              className="rounded-lg object-cover w-full h-full"
            />
          </div>

          <h1 className="text-4xl font-bold mb-4">{tour.title}</h1>

          <div className="flex gap-4 mb-6">
            <Badge variant="outline">
              <Clock className="mr-1 h-4 w-4" />
              {tour.duration} days
            </Badge>
            <Badge variant="outline">
              <MapPin className="mr-1 h-4 w-4" />
              {tour.location}
            </Badge>
            <Badge>${tour.price}</Badge>
          </div>

          <div className="prose max-w-none mb-8">
            <p>{tour.description}</p>
          </div>

          <div className="mb-8">
            <h3 className="text-xl font-semibold mb-4">What's Included</h3>
            <ul className="grid gap-2">
              {tour.included.map((item, i) => (
                <li key={i} className="flex items-center gap-2">
                  <Check className="h-4 w-4 text-green-500" />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div>
          <div className="sticky top-24">
            <div className="bg-card rounded-lg p-6 border">
              <h3 className="text-xl font-semibold mb-6">Book This Tour</h3>

              <Form {...form}>
                <form onSubmit={form.handleSubmit(data => bookingMutation.mutate(data))} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="name"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Name</FormLabel>
                        <FormControl>
                          <Input {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="date"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Preferred Date</FormLabel>
                        <FormControl>
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            className="rounded-md border"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="participants"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Number of Participants</FormLabel>
                        <FormControl>
                          <Input type="number" min="1" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="specialRequests"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Special Requests</FormLabel>
                        <FormControl>
                          <Textarea {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button
                    type="submit"
                    className="w-full"
                    disabled={bookingMutation.isPending}
                  >
                    {bookingMutation.isPending ? "Submitting..." : "Book Now"}
                  </Button>
                </form>
              </Form>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}