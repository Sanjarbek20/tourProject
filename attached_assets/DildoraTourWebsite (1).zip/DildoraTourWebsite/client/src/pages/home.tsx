import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { TourCard } from "@/components/tour-card";
import { useQuery } from "@tanstack/react-query";
import type { Tour } from "@shared/schema";

export default function Home() {
  const { data: tours, isLoading } = useQuery<Tour[]>({
    queryKey: ["/api/tours"]
  });

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section 
        className="relative py-32 px-6 text-center text-white"
        style={{
          backgroundImage: "linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.7))",
          backgroundColor: "hsl(var(--primary))"
        }}
      >
        <div className="container max-w-4xl mx-auto">
          <h1 className="text-4xl md:text-6xl font-bold mb-6">
            Discover the Beauty of Uzbekistan
          </h1>
          <p className="text-lg md:text-xl mb-8 opacity-90">
            Experience the rich history, culture and natural wonders with our expertly crafted tours
          </p>
          <Button 
            size="lg" 
            variant="secondary" 
            asChild
          >
            <Link href="/tours">
              Explore Tours
            </Link>
          </Button>
        </div>
      </section>

      {/* Featured Tours */}
      <section className="py-16 container">
        <h2 className="text-3xl font-bold text-center mb-12">
          Popular Tours
        </h2>
        {isLoading ? (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {[1,2,3].map(i => (
              <div key={i} className="h-[400px] animate-pulse bg-muted rounded-lg" />
            ))}
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {tours?.slice(0,3).map(tour => (
              <TourCard key={tour.id} tour={tour} />
            ))}
          </div>
        )}
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-muted">
        <div className="container">
          <h2 className="text-3xl font-bold text-center mb-12">
            Why Choose DildoraTour
          </h2>
          <div className="grid gap-8 md:grid-cols-3">
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Expert Guides</h3>
              <p className="text-muted-foreground">
                Professional local guides with deep knowledge of Uzbekistan
              </p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Unique Experiences</h3>
              <p className="text-muted-foreground">
                Carefully crafted itineraries that go beyond tourist spots
              </p>
            </div>
            <div className="text-center">
              <h3 className="text-xl font-semibold mb-4">Local Expertise</h3>
              <p className="text-muted-foreground">
                Authentic cultural experiences and insider access
              </p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}