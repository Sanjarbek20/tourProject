import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';
import LanguageDetector from 'i18next-browser-languagedetector';

// English translations
const enTranslations = {
  worker: {
    dashboard: {
      title: 'Booking Orders',
      logout: 'Logout',
      loggingOut: 'Logging out...',
      noBookings: 'No bookings yet',
      bookingDetails: {
        bookingNumber: 'Booking #{{number}}',
        customerDetails: 'Customer Details',
        specialRequests: 'Special Requests',
        name: 'Name: {{name}}',
        email: 'Email: {{email}}',
        participants: 'Participants: {{count}}',
        tour: 'Tour: {{title}}'
      }
    },
    login: {
      title: 'Worker Login',
      username: 'Username',
      password: 'Password',
      loginButton: 'Login',
      loggingIn: 'Logging in...',
      success: 'Login successful',
      welcome: 'Welcome back!',
      error: 'Login failed',
      invalidCredentials: 'Invalid username or password'
    }
  }
};

// Uzbek translations
const uzTranslations = {
  worker: {
    dashboard: {
      title: 'Buyurtmalar',
      logout: 'Chiqish',
      loggingOut: 'Chiqilmoqda...',
      noBookings: 'Hozircha buyurtmalar yoʻq',
      bookingDetails: {
        bookingNumber: 'Buyurtma #{{number}}',
        customerDetails: 'Mijoz maʼlumotlari',
        specialRequests: 'Maxsus soʻrovlar',
        name: 'Ism: {{name}}',
        email: 'Email: {{email}}',
        participants: 'Ishtirokchilar soni: {{count}}',
        tour: 'Sayohat: {{title}}'
      }
    },
    login: {
      title: 'Xodim kirishi',
      username: 'Foydalanuvchi nomi',
      password: 'Parol',
      loginButton: 'Kirish',
      loggingIn: 'Kirilmoqda...',
      success: 'Muvaffaqiyatli kirish',
      welcome: 'Xush kelibsiz!',
      error: 'Kirishda xatolik',
      invalidCredentials: 'Notoʻgʻri foydalanuvchi nomi yoki parol'
    }
  }
};

i18n
  .use(LanguageDetector)
  .use(initReactI18next)
  .init({
    resources: {
      en: { translation: enTranslations },
      uz: { translation: uzTranslations }
    },
    fallbackLng: 'en',
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;
