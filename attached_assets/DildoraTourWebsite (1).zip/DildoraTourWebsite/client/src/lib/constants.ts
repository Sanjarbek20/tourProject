export const TOUR_CATEGORIES = [
  { value: "cultural", label: "Cultural" },
  { value: "adventure", label: "Adventure" },
  { value: "nature", label: "Nature" },
  { value: "food", label: "Food & Culinary" }
];

export const DIFFICULTY_LEVELS = [
  { value: "easy", label: "Easy" },
  { value: "moderate", label: "Moderate" },
  { value: "challenging", label: "Challenging" }
];
