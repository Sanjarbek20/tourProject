import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, MapPin, DollarSign } from "lucide-react";
import type { Tour } from "@shared/schema";
import { Link } from "wouter";

interface TourCardProps {
  tour: Tour;
}

export function TourCard({ tour }: TourCardProps) {
  return (
    <Card className="overflow-hidden">
      <div className="aspect-video relative">
        <img
          src={tour.image}
          alt={tour.title}
          className="object-cover w-full h-full"
        />
        <Badge className="absolute top-4 right-4">
          {tour.category}
        </Badge>
      </div>
      <CardHeader>
        <h3 className="text-xl font-semibold">{tour.title}</h3>
        <p className="text-sm text-muted-foreground line-clamp-2">
          {tour.description}
        </p>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4 text-sm">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>{tour.duration} days</span>
          </div>
          <div className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            <span>{tour.location}</span>
          </div>
          <div className="flex items-center gap-1">
            <DollarSign className="h-4 w-4" />
            <span>${tour.price}</span>
          </div>
        </div>
      </CardContent>
      <CardFooter>
        <Link href={`/tours/${tour.id}`}>
          <Button className="w-full">View Details</Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
