import { Link } from "wouter";

export function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container py-12 grid gap-8 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <h3 className="text-lg font-semibold mb-4">DildoraTour</h3>
          <p className="text-sm text-muted-foreground">
            Your trusted partner for unforgettable Uzbekistan adventures.
          </p>
        </div>
        <div>
          <h4 className="font-medium mb-4">Quick Links</h4>
          <ul className="space-y-2">
            <li><Link href="/tours">Tours</Link></li>
            <li><Link href="/about">About Us</Link></li>
            <li><Link href="/contact">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium mb-4">Contact Info</h4>
          <ul className="space-y-2 text-sm">
            <li>Email: info@dildoratour.uz</li>
            <li>Phone: +998 90 123 45 67</li>
            <li>Address: Tashkent, Uzbekistan</li>
          </ul>
        </div>
        <div>
          <h4 className="font-medium mb-4">Follow Us</h4>
          <div className="flex space-x-4">
            {/* Add social media links here */}
          </div>
        </div>
      </div>
      <div className="border-t">
        <div className="container py-6 text-center text-sm">
          <p>&copy; {new Date().getFullYear()} DildoraTour. All rights reserved.</p>
        </div>
      </div>
    </footer>
  );
}
